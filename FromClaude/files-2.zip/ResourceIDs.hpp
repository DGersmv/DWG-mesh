#pragma once

// Menu
static const short TopoMeshMenuResId    = 32501;
static const short TopoMeshMenuItemIndex = 1;

// Palette dialog
static const short TopoMeshPaletteResId  = 32500;
static const short TopoMeshBrowserCtrlId = 1;

// HTML resource
static const short TopoMeshHtmlResId     = 100;
