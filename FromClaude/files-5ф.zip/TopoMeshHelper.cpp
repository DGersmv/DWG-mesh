#include "TopoMeshHelper.hpp"

#include "APIEnvir.h"
#include "ACAPinc.h"

#include <cmath>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <vector>
#include <limits>

// =============================================================================
// Внутренние структуры
// =============================================================================

namespace {

struct TopoPoint {
	double x;   // метры (ArchiCAD internal)
	double y;
	double z;
};

struct ParseParams {
	Int32         layerIdx;      // 0-based порядковый номер из нашего списка
	double        radiusMm;      // радиус поиска текста (мм)
	char          separator;     // '.' или ','
	Int32         mFactor;       // множитель метров (обычно 1)
	Int32         mmFactor;      // множитель мм     (обычно 1000)
	Int32         storyIdx;      // индекс этажа ArchiCAD
	double        bboxOffsetMm;  // отступ bounding box (мм)
	GS::UniString meshName;      // имя элемента
	Int32         meshLayerIdx;  // 0-based порядковый номер слоя для Mesh
};

// =============================================================================
// Простой парсер плоского JSON (без внешних зависимостей)
// =============================================================================

static GS::UniString JsonGetString(const GS::UniString& json, const char* key)
{
	GS::UniString searchKey = GS::UniString("\"") + key + "\":";
	const char* src   = json.ToCStr().Get();
	const char* found = std::strstr(src, searchKey.ToCStr().Get());
	if (found == nullptr) return GS::EmptyUniString;

	const char* val = found + std::strlen(searchKey.ToCStr().Get());
	while (*val == ' ') ++val;

	if (*val == '"') {
		++val;
		const char* end = std::strchr(val, '"');
		if (end == nullptr) return GS::EmptyUniString;
		char buf[512] = {};
		std::strncpy(buf, val, (size_t)(end - val));
		return GS::UniString(buf);
	} else {
		char buf[64] = {};
		int i = 0;
		while (*val && *val != ',' && *val != '}' && *val != ' ' && i < 63)
			buf[i++] = *val++;
		return GS::UniString(buf);
	}
}

static double JsonGetDouble(const GS::UniString& json, const char* key, double def = 0.0)
{
	GS::UniString s = JsonGetString(json, key);
	if (s.IsEmpty()) return def;
	double out = def;
	std::sscanf(s.ToCStr().Get(), "%lf", &out);
	return out;
}

static Int32 JsonGetInt(const GS::UniString& json, const char* key, Int32 def = 0)
{
	GS::UniString s = JsonGetString(json, key);
	if (s.IsEmpty()) return def;
	Int32 out = def;
	std::sscanf(s.ToCStr().Get(), "%d", &out);
	return out;
}

// =============================================================================
// Парсинг параметров из JSON
// =============================================================================

static bool ParseJsonParams(const GS::UniString& json, ParseParams& p)
{
	p.layerIdx     = JsonGetInt   (json, "layerIdx",   -1);
	p.radiusMm     = JsonGetDouble(json, "radius",   3000.0);
	p.mFactor      = JsonGetInt   (json, "mFactor",     1);
	p.mmFactor     = JsonGetInt   (json, "mmFactor",  1000);
	p.storyIdx     = JsonGetInt   (json, "storyIdx",    0);
	p.bboxOffsetMm = JsonGetDouble(json, "bboxOffset", 1000.0);
	p.meshName     = JsonGetString(json, "meshName");
	p.meshLayerIdx = JsonGetInt   (json, "meshLayer",   0);

	if (p.meshName.IsEmpty()) p.meshName = "TopoMesh";

	GS::UniString sep = JsonGetString(json, "separator");
	p.separator = (sep == ",") ? ',' : '.';

	if (p.layerIdx < 0) {
		ACAPI_WriteReport("[TopoMesh] Ошибка: layerIdx не задан", false);
		return false;
	}
	return true;
}

// =============================================================================
// Парсинг высотной отметки из строки текста
// Форматы: "14.200", "14,200", "+14.2", "-0.450"
// Возвращает высоту в мм
// =============================================================================

static bool ParseElevationText(const char* text, char separator, double& outMm)
{
	if (text == nullptr || text[0] == '\0') return false;

	while (*text == ' ') ++text;

	bool negative = false;
	if      (*text == '+') ++text;
	else if (*text == '-') { negative = true; ++text; }

	// Заменяем разделитель на '.' для sscanf
	char buf[64] = {};
	std::strncpy(buf, text, 63);
	for (int i = 0; buf[i]; ++i)
		if (buf[i] == separator) buf[i] = '.';

	double val = 0.0;
	if (std::sscanf(buf, "%lf", &val) != 1) return false;

	// val в метрах → мм
	outMm = val * 1000.0;
	if (negative) outMm = -outMm;

	return true;
}

// =============================================================================
// API_AttributeIndex слоя по 0-based порядковому номеру из нашего списка
// =============================================================================

static API_AttributeIndex GetLayerAttrIndex(Int32 listIndex)
{
	API_Attribute attrib = {};
	attrib.header.typeID = API_LayerID;

	Int32 current = 0;
	short attrIdx = 1;

	while (attrIdx <= 4096) {
		attrib.header.index = attrIdx;
		if (ACAPI_Attribute_Get(&attrib) != NoError) {
			++attrIdx;
			continue;
		}
		if (current == listIndex)
			return attrib.header.index;
		++current;
		++attrIdx;
	}
	return 1; // fallback
}

// =============================================================================
// Сбор элементов на слое
// =============================================================================

struct ArcPoint  { double x, y; };
struct TextItem  { double x, y; GS::UniString text; };

static void CollectElementsOnLayer(API_AttributeIndex layerAttrIdx,
	std::vector<ArcPoint>& arcs,
	std::vector<TextItem>& texts)
{
	// --- Arc / Circle ---
	GS::Array<API_Guid> arcList;
	ACAPI_Element_GetElemList(API_ArcID, &arcList);

	for (const API_Guid& guid : arcList) {
		API_Element elem = {};
		elem.header.guid = guid;
		if (ACAPI_Element_Get(&elem) != NoError) continue;
		if (elem.header.layer != layerAttrIdx) continue;

		arcs.push_back({ elem.arc.origC.x, elem.arc.origC.y });
	}

	// --- Text ---
	GS::Array<API_Guid> textList;
	ACAPI_Element_GetElemList(API_TextID, &textList);

	for (const API_Guid& guid : textList) {
		API_Element elem = {};
		elem.header.guid = guid;
		if (ACAPI_Element_Get(&elem) != NoError) continue;
		if (elem.header.layer != layerAttrIdx) continue;

		API_ElementMemo memo = {};
		if (ACAPI_Element_GetMemo(guid, &memo, APIMemoMask_TextContent) != NoError) continue;

		TextItem ti;
		ti.x = elem.text.loc.x;
		ti.y = elem.text.loc.y;

		if (memo.textContent != nullptr && *memo.textContent != nullptr)
			ti.text = GS::UniString(*memo.textContent);

		ACAPI_DisposeElemMemoHdls(&memo);

		if (!ti.text.IsEmpty())
			texts.push_back(ti);
	}
}

// =============================================================================
// Сопоставление Arc ↔ ближайший Text в радиусе
// =============================================================================

static inline double Dist2(double ax, double ay, double bx, double by)
{
	const double dx = ax - bx, dy = ay - by;
	return dx * dx + dy * dy;
}

static std::vector<TopoPoint> MatchPoints(
	const std::vector<ArcPoint>& arcs,
	const std::vector<TextItem>& texts,
	double radiusMm,
	char   separator)
{
	const double radiusM = radiusMm / 1000.0;
	const double r2      = radiusM * radiusM;

	std::vector<TopoPoint> result;
	result.reserve(arcs.size());

	for (const ArcPoint& arc : arcs) {
		double           bestD2   = std::numeric_limits<double>::max();
		const TextItem*  bestText = nullptr;

		for (const TextItem& ti : texts) {
			const double d2 = Dist2(arc.x, arc.y, ti.x, ti.y);
			if (d2 <= r2 && d2 < bestD2) {
				bestD2   = d2;
				bestText = &ti;
			}
		}

		if (bestText == nullptr) continue;

		double elevMm = 0.0;
		if (!ParseElevationText(bestText->text.ToCStr().Get(), separator, elevMm))
			continue;

		result.push_back({ arc.x, arc.y, elevMm / 1000.0 }); // мм → метры
	}

	return result;
}

// =============================================================================
// Высота этажа (метры)
// =============================================================================

static double GetStoryElevationM(Int32 storyIdx)
{
	API_StoryInfo storyInfo = {};
	if (ACAPI_Environment(APIEnv_GetStorySettingsID, &storyInfo) != NoError)
		return 0.0;

	double elevation = 0.0;
	const short nStories = storyInfo.lastStory - storyInfo.firstStory + 1;

	for (short i = 0; i < nStories; ++i) {
		if (storyInfo.data[i].index == (short)storyIdx) {
			elevation = storyInfo.data[i].level;
			break;
		}
	}

	BMpKill(reinterpret_cast<GSPtr*>(&storyInfo.data));
	return elevation;
}

// =============================================================================
// Создание Mesh — по образцу CreateSlabFromContour из BuildHelper.cpp
// =============================================================================

static GSErrCode BuildMesh(const std::vector<TopoPoint>& points,
	const ParseParams& p,
	double storyElevM)
{
	if (points.size() < 3) {
		ACAPI_WriteReport("[TopoMesh] Менее 3 точек (%d), Mesh не создаётся", false, (int)points.size());
		return APIERR_GENERAL;
	}

	// --- Bounding box ---
	const double offsetM = p.bboxOffsetMm / 1000.0;

	double minX = points[0].x, maxX = points[0].x;
	double minY = points[0].y, maxY = points[0].y;
	double minZ = points[0].z;

	for (const TopoPoint& pt : points) {
		if (pt.x < minX) minX = pt.x;
		if (pt.x > maxX) maxX = pt.x;
		if (pt.y < minY) minY = pt.y;
		if (pt.y > maxY) maxY = pt.y;
		if (pt.z < minZ) minZ = pt.z;
	}

	minX -= offsetM; minY -= offsetM;
	maxX += offsetM; maxY += offsetM;

	// Контур: 4 угловые точки (+ замыкающая = 5 в coords)
	// Внутренние топо точки идут после контура
	const Int32 nCorners   = 4;
	const Int32 nCoordsContour = nCorners + 1;             // +1 замыкающая
	const Int32 nTopoPoints    = (Int32)points.size();
	const Int32 nCoordsTotal   = nCoordsContour + nTopoPoints; // весь массив coords

	// --- Defaults ---
	API_Element     elem = {};
	API_ElementMemo memo = {};
	BNZeroMemory(&elem, sizeof(API_Element));
	BNZeroMemory(&memo, sizeof(API_ElementMemo));

	elem.header.type = API_MeshID;
	GSErrCode err = ACAPI_Element_GetDefaults(&elem, &memo);
	if (err != NoError) {
		ACAPI_WriteReport("[TopoMesh] GetDefaults failed: %d", false, (int)err);
		ACAPI_DisposeElemMemoHdls(&memo);
		return err;
	}

	// --- Настройка заголовка ---
	elem.header.layer    = (short)GetLayerAttrIndex(p.meshLayerIdx);
	elem.mesh.head.floorInd = (short)p.storyIdx;

	// Имя элемента
	GS::ucsncpy(elem.mesh.head.elemID.elemIDStr,
		p.meshName.ToUStr().Get(),
		sizeof(elem.mesh.head.elemID.elemIDStr) / sizeof(GS::uchar_t) - 1);

	// level — нижняя грань относительно reference plane этажа
	elem.mesh.level = minZ - storyElevM;

	// Полигон: контур из nCorners вершин + nTopoPoints внутренних точек
	elem.mesh.poly.nCoords    = nCoordsContour;   // вершин контура (с замыкающей)
	elem.mesh.poly.nSubPolys  = 1;
	elem.mesh.poly.nArcs      = 0;

	// --- Выделяем memo (по образцу BuildHelper::CreateSlabFromContour) ---
	ACAPI_DisposeElemMemoHdls(&memo);

	// coords: 1-based, размер (nCoordsTotal + 1)
	memo.coords = reinterpret_cast<API_Coord**>(
		BMAllocateHandle((nCoordsTotal + 1) * (GSSize)sizeof(API_Coord), ALLOCATE_CLEAR, 0));

	// meshPolyZ: 1-based, размер (nCoordsTotal + 1)
	memo.meshPolyZ = reinterpret_cast<double**>(
		BMAllocateHandle((nCoordsTotal + 1) * (GSSize)sizeof(double), ALLOCATE_CLEAR, 0));

	// pends: [0, nCoordsContour] — один контур
	memo.pends = reinterpret_cast<Int32**>(
		BMAllocateHandle(2 * (GSSize)sizeof(Int32), ALLOCATE_CLEAR, 0));

	if (memo.coords == nullptr || memo.meshPolyZ == nullptr || memo.pends == nullptr) {
		ACAPI_WriteReport("[TopoMesh] Ошибка выделения памяти", false);
		ACAPI_DisposeElemMemoHdls(&memo);
		return APIERR_MEMFULL;
	}

	// --- Угловые точки контура (индексы 1..4, +5 замыкающая) ---
	const double cornersXY[4][2] = {
		{ minX, minY },
		{ maxX, minY },
		{ maxX, maxY },
		{ minX, maxY }
	};
	const double cornerZ = minZ - storyElevM; // относительно reference plane

	for (Int32 i = 0; i < nCorners; ++i) {
		(*memo.coords)   [i + 1].x = cornersXY[i][0];
		(*memo.coords)   [i + 1].y = cornersXY[i][1];
		(*memo.meshPolyZ)[i + 1]   = cornerZ;
	}
	// Замыкающая точка контура
	(*memo.coords)   [nCorners + 1] = (*memo.coords)[1];
	(*memo.meshPolyZ)[nCorners + 1] = cornerZ;

	// --- Внутренние топо точки (индексы 6..nCoordsTotal) ---
	for (Int32 i = 0; i < nTopoPoints; ++i) {
		const Int32 idx = nCoordsContour + i + 1;
		(*memo.coords)   [idx].x = points[i].x;
		(*memo.coords)   [idx].y = points[i].y;
		(*memo.meshPolyZ)[idx]   = points[i].z - storyElevM;
	}

	// --- pends ---
	(*memo.pends)[0] = 0;
	(*memo.pends)[1] = nCoordsContour;

	// --- Создаём элемент ---
	err = ACAPI_Element_Create(&elem, &memo);
	ACAPI_DisposeElemMemoHdls(&memo);

	if (err != NoError)
		ACAPI_WriteReport("[TopoMesh] ACAPI_Element_Create failed: %d", false, (int)err);
	else
		ACAPI_WriteReport("[TopoMesh] Mesh создан (%d топо точек)", false, nTopoPoints);

	return err;
}

} // anonymous namespace

// =============================================================================
// Публичный API
// =============================================================================

namespace TopoMeshHelper {

GS::UniString GetLayerListJson()
{
	GS::UniString json = "[";
	bool  first   = true;
	Int32 listIdx = 0;
	short attrIdx = 1;

	API_Attribute attrib = {};
	attrib.header.typeID = API_LayerID;

	while (attrIdx <= 4096) {
		attrib.header.index = attrIdx;
		if (ACAPI_Attribute_Get(&attrib) == NoError) {
			if (!first) json += ",";
			first = false;

			GS::UniString name = GS::UniString(attrib.layer.head.name);
			// Экранируем кавычки
			GS::UniString escaped;
			for (UInt32 ci = 0; ci < name.GetLength(); ++ci) {
				if (name[ci] == '"') escaped += "\\\"";
				else                 escaped += name[ci];
			}

			char buf[256];
			std::snprintf(buf, sizeof(buf),
				"{\"name\":\"%s\",\"index\":%d}",
				escaped.ToCStr().Get(), (int)listIdx);
			json += buf;
			++listIdx;
		}
		++attrIdx;
	}

	json += "]";
	return json;
}

GS::UniString GetStoryListJson()
{
	API_StoryInfo storyInfo = {};
	if (ACAPI_Environment(APIEnv_GetStorySettingsID, &storyInfo) != NoError)
		return "[]";

	GS::UniString json = "[";
	const short nStories = storyInfo.lastStory - storyInfo.firstStory + 1;

	for (short i = 0; i < nStories; ++i) {
		if (i > 0) json += ",";

		GS::UniString name = GS::UniString(storyInfo.data[i].uName);
		GS::UniString escaped;
		for (UInt32 ci = 0; ci < name.GetLength(); ++ci) {
			if (name[ci] == '"') escaped += "\\\"";
			else                 escaped += name[ci];
		}

		char buf[256];
		std::snprintf(buf, sizeof(buf),
			"{\"name\":\"%s\",\"index\":%d}",
			escaped.ToCStr().Get(), (int)storyInfo.data[i].index);
		json += buf;
	}

	BMpKill(reinterpret_cast<GSPtr*>(&storyInfo.data));
	json += "]";
	return json;
}

GS::UniString GetSampleElevationText(Int32 layerIdx)
{
	const API_AttributeIndex layerAttrIdx = GetLayerAttrIndex(layerIdx);

	GS::Array<API_Guid> textList;
	ACAPI_Element_GetElemList(API_TextID, &textList);

	for (const API_Guid& guid : textList) {
		API_Element elem = {};
		elem.header.guid = guid;
		if (ACAPI_Element_Get(&elem) != NoError) continue;
		if (elem.header.layer != layerAttrIdx) continue;

		API_ElementMemo memo = {};
		if (ACAPI_Element_GetMemo(guid, &memo, APIMemoMask_TextContent) != NoError) continue;

		GS::UniString result;
		if (memo.textContent != nullptr && *memo.textContent != nullptr)
			result = GS::UniString(*memo.textContent);

		ACAPI_DisposeElemMemoHdls(&memo);

		if (!result.IsEmpty()) return result;
	}

	return "(текстов на слое не найдено)";
}

bool CreateTopoMesh(const GS::UniString& jsonPayload)
{
	// 1. Парсим параметры
	ParseParams params = {};
	if (!ParseJsonParams(jsonPayload, params)) return false;

	// 2. Индекс слоя → API_AttributeIndex
	const API_AttributeIndex layerAttrIdx = GetLayerAttrIndex(params.layerIdx);

	// 3. Собираем элементы со слоя
	std::vector<ArcPoint> arcs;
	std::vector<TextItem> texts;
	CollectElementsOnLayer(layerAttrIdx, arcs, texts);

	ACAPI_WriteReport("[TopoMesh] Дуг: %d, текстов: %d", false,
		(int)arcs.size(), (int)texts.size());

	if (arcs.empty()) {
		ACAPI_WriteReport("[TopoMesh] Нет Arc/Circle на слое", false);
		return false;
	}
	if (texts.empty()) {
		ACAPI_WriteReport("[TopoMesh] Нет текстов на слое", false);
		return false;
	}

	// 4. Сопоставляем Arc ↔ Text
	std::vector<TopoPoint> topoPoints = MatchPoints(
		arcs, texts, params.radiusMm, params.separator);

	ACAPI_WriteReport("[TopoMesh] Сопоставлено точек: %d", false, (int)topoPoints.size());

	if (topoPoints.size() < 3) {
		ACAPI_WriteReport("[TopoMesh] Слишком мало точек после сопоставления", false);
		return false;
	}

	// 5. Высота этажа
	const double storyElevM = GetStoryElevationM(params.storyIdx);

	// 6. Создаём Mesh напрямую (как в BuildHelper)
	const GSErrCode err = BuildMesh(topoPoints, params, storyElevM);
	return (err == NoError);
}

} // namespace TopoMeshHelper
